public class snowtam {
String A;
String B;
String C;
String D;
String E;
String F;


    public String getA() {
        return A;
    }

    public void setA(String a) {
        A = a;
    }
}
