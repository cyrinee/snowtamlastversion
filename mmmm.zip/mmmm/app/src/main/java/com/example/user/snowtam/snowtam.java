package com.example.user.snowtam;

public class snowtam {

    private String name;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }}

